import streamlit as st
import cv2
from PIL import Image
import numpy as np
from io import BytesIO
import matplotlib.pyplot as plt
from scipy import ndimage

# Função para upload ou captura de imagem
def upload_or_capture():
    col1, col2 = st.columns(2)
    with col1:
        uploaded = st.file_uploader("Envie uma imagem", type=["png", "jpg", "jpeg"])
        if uploaded:
            image = Image.open(uploaded)
            return np.array(image.convert('RGB'))
    with col2:
        if st.button("Capturar da webcam"):
            cap = cv2.VideoCapture(0)
            ret, frame = cap.read()
            cap.release()
            if ret:
                return cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    return None

# Funções de processamento básico
@st.cache_data
def rotate_image(image, angle):
    return ndimage.rotate(image, angle, reshape=False)

@st.cache_data
def scale_image(image, scale):
    h, w = image.shape[:2]
    new_w = int(w * scale)
    new_h = int(h * scale)
    return cv2.resize(image, (new_w, new_h), interpolation=cv2.INTER_LINEAR)

# Novos filtros de cor
@st.cache_data
def apply_sepia(image):
    sepia_filter = np.array([[0.393, 0.769, 0.189], 
                            [0.349, 0.686, 0.168], 
                            [0.272, 0.534, 0.131]])
    sepia_img = cv2.transform(image, sepia_filter)
    sepia_img = np.clip(sepia_img, 0, 255).astype(np.uint8)
    return sepia_img

@st.cache_data
def apply_grayscale(image):
    return cv2.cvtColor(cv2.cvtColor(image, cv2.COLOR_RGB2GRAY), cv2.COLOR_GRAY2RGB)

@st.cache_data
def apply_cool(image):
    # Aumenta o azul, diminui o vermelho
    img_cool = image.copy()
    img_cool[:,:,0] = np.clip(img_cool[:,:,0] * 0.7, 0, 255).astype(np.uint8)  # Reduz vermelho
    img_cool[:,:,2] = np.clip(img_cool[:,:,2] * 1.3, 0, 255).astype(np.uint8)  # Aumenta azul
    return img_cool

@st.cache_data
def apply_warm(image):
    # Aumenta o vermelho, diminui o azul
    img_warm = image.copy()
    img_warm[:,:,0] = np.clip(img_warm[:,:,0] * 1.3, 0, 255).astype(np.uint8)  # Aumenta vermelho
    img_warm[:,:,2] = np.clip(img_warm[:,:,2] * 0.7, 0, 255).astype(np.uint8)  # Reduz azul
    return img_warm

# Filtros de nitidez e desfoque
@st.cache_data
def apply_blur(image, kernel_size):
    return cv2.GaussianBlur(image, (kernel_size, kernel_size), 0)

@st.cache_data
def apply_sharpen(image, amount):
    kernel = np.array([[-1, -1, -1],
                       [-1, 9 + amount, -1],
                       [-1, -1, -1]])
    return cv2.filter2D(image, -1, kernel)

# Detecção de bordas
@st.cache_data
def detect_edges(image, threshold1, threshold2):
    gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
    edges = cv2.Canny(gray, threshold1, threshold2)
    return cv2.cvtColor(edges, cv2.COLOR_GRAY2RGB)

# Ajustes de cor HSV
@st.cache_data
def adjust_hsv(image, hue, saturation, value):
    hsv = cv2.cvtColor(image, cv2.COLOR_RGB2HSV).astype(np.float32)
    
    # Ajuste de matiz (hue)
    hsv[:,:,0] = (hsv[:,:,0] + hue) % 180
    
    # Ajuste de saturação
    hsv[:,:,1] = np.clip(hsv[:,:,1] * saturation, 0, 255)
    
    # Ajuste de valor (brilho)
    hsv[:,:,2] = np.clip(hsv[:,:,2] * value, 0, 255)
    
    hsv = hsv.astype(np.uint8)
    return cv2.cvtColor(hsv, cv2.COLOR_HSV2RGB)

# Efeitos artísticos
@st.cache_data
def apply_cartoon(image, edges=1, bilateral=7):
    gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
    gray = cv2.medianBlur(gray, 5)
    edges = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY, 9, edges)
    color = cv2.bilateralFilter(image, bilateral, 300, 300)
    cartoon = cv2.bitwise_and(color, color, mask=edges)
    return cartoon

@st.cache_data
def apply_vignette(image, amount):
    height, width = image.shape[:2]
    x_kernel = cv2.getGaussianKernel(width, width/amount)
    y_kernel = cv2.getGaussianKernel(height, height/amount)
    kernel = y_kernel * x_kernel.T
    mask = kernel / kernel.max()
    
    vignette = image.copy()
    for i in range(3):
        vignette[:,:,i] = vignette[:,:,i] * mask
        
    return vignette.astype(np.uint8)

# Histograma
def plot_histogram(image):
    fig, ax = plt.subplots(figsize=(8, 3))
    
    colors = ('r', 'g', 'b')
    for i, color in enumerate(colors):
        hist = cv2.calcHist([image], [i], None, [256], [0, 256])
        ax.plot(hist, color=color)
        
    ax.set_xlim([0, 256])
    ax.set_title('Histograma RGB')
    ax.grid(True)
    return fig

# Inicializa sessão de estado
if 'orig_image' not in st.session_state:
    st.session_state.orig_image = None

st.title("Editor de Imagens Avançado")
st.subheader("Transforme suas fotos com filtros profissionais")

# Entrada de imagem
image = upload_or_capture()
if image is not None:
    st.session_state.orig_image = image

# Aplica transformações quando imagem disponível
if st.session_state.orig_image is not None:
    original = st.session_state.orig_image
    
    # Sidebar para controles
    st.sidebar.title("Controles de Edição")
    
    # Abas para categorias de filtros
    tab_basic, tab_color, tab_effects, tab_artistic = st.tabs(["Básico", "Cor", "Efeitos", "Artístico"])
    
    with tab_basic:
        st.subheader("Ajustes Básicos")
        rotate = st.slider("Rotação (graus)", -180, 180, 0)
        scale = st.slider("Escala", 0.5, 2.0, 1.0, step=0.1)
        
        # Corte
        crop = st.checkbox("Ativar corte")
        if crop:
            col1, col2 = st.columns(2)
            with col1:
                crop_top = st.slider("Corte superior (%)", 0, 49, 0)
                crop_left = st.slider("Corte esquerdo (%)", 0, 49, 0)
            with col2:
                crop_bottom = st.slider("Corte inferior (%)", 0, 49, 0)
                crop_right = st.slider("Corte direito (%)", 0, 49, 0)
    
    with tab_color:
        st.subheader("Ajustes de Cor")
        
        # Filtros de cor predefinidos
        color_filter = st.selectbox("Filtro de cor", 
                                   ["Nenhum", "Sépia", "Preto e Branco", "Frio", "Quente"])
        
        # Ajustes HSV
        st.subheader("Ajustes HSV")
        hue = st.slider("Matiz", -30, 30, 0)
        saturation = st.slider("Saturação", 0.0, 2.0, 1.0, step=0.1)
        value = st.slider("Valor (Brilho)", 0.0, 2.0, 1.0, step=0.1)
        
        # Ajustes RGB
        st.subheader("Canais RGB")
        r_adjust = st.slider("Vermelho", 0.0, 2.0, 1.0, step=0.1)
        g_adjust = st.slider("Verde", 0.0, 2.0, 1.0, step=0.1)
        b_adjust = st.slider("Azul", 0.0, 2.0, 1.0, step=0.1)
    
    with tab_effects:
        st.subheader("Efeitos Especiais")
        
        # Nitidez e desfoque
        blur = st.slider("Desfoque", 0, 25, 0, step=2)
        sharpen = st.slider("Nitidez", 0.0, 5.0, 0.0, step=0.5)
        
        # Detecção de bordas
        edge_detect = st.checkbox("Detecção de bordas")
        if edge_detect:
            edge_t1 = st.slider("Limiar 1", 0, 255, 100)
            edge_t2 = st.slider("Limiar 2", 0, 255, 200)
    
    with tab_artistic:
        st.subheader("Efeitos Artísticos")
        
        # Efeito cartoon
        cartoon = st.checkbox("Efeito cartoon")
        if cartoon:
            cartoon_edge = st.slider("Intensidade de bordas", 1, 10, 5)
            cartoon_bilateral = st.slider("Suavidade", 3, 15, 7, step=2)
        
        # Vinheta
        vignette = st.slider("Vinheta", 0.0, 10.0, 0.0, step=0.5)
    
    # Processamento da imagem
    processed = original.copy()
    
    # Aplicar transformações básicas
    if rotate != 0:
        processed = rotate_image(processed, rotate)
    
    if scale != 1.0:
        processed = scale_image(processed, scale)
    
    # Aplicar corte se ativado
    if crop:
        h, w = processed.shape[:2]
        top = int(h * crop_top / 100)
        bottom = int(h * (1 - crop_bottom / 100))
        left = int(w * crop_left / 100)
        right = int(w * (1 - crop_right / 100))
        processed = processed[top:bottom, left:right]
    
    # Aplicar filtros de cor
    if color_filter == "Sépia":
        processed = apply_sepia(processed)
    elif color_filter == "Preto e Branco":
        processed = apply_grayscale(processed)
    elif color_filter == "Frio":
        processed = apply_cool(processed)
    elif color_filter == "Quente":
        processed = apply_warm(processed)
    
    # Aplicar ajustes HSV
    if hue != 0 or saturation != 1.0 or value != 1.0:
        processed = adjust_hsv(processed, hue, saturation, value)
    
    # Aplicar ajustes RGB
    if r_adjust != 1.0 or g_adjust != 1.0 or b_adjust != 1.0:
        processed = processed.astype(np.float32)
        processed[:,:,0] = np.clip(processed[:,:,0] * r_adjust, 0, 255)
        processed[:,:,1] = np.clip(processed[:,:,1] * g_adjust, 0, 255)
        processed[:,:,2] = np.clip(processed[:,:,2] * b_adjust, 0, 255)
        processed = processed.astype(np.uint8)
    
    # Aplicar efeitos
    if blur > 0:
        # Garantir que o kernel seja ímpar
        blur_kernel = blur if blur % 2 == 1 else blur + 1
        processed = apply_blur(processed, blur_kernel)
    
    if sharpen > 0:
        processed = apply_sharpen(processed, sharpen)
    
    if edge_detect:
        processed = detect_edges(processed, edge_t1, edge_t2)
    
    # Aplicar efeitos artísticos
    if cartoon:
        processed = apply_cartoon(processed, cartoon_edge, cartoon_bilateral)
    
    if vignette > 0:
        processed = apply_vignette(processed, vignette)
    
    # Exibição lado a lado
    col_orig, col_proc = st.columns(2)
    with col_orig:
        st.image(original, caption="Imagem Original", use_column_width=True)
        
        # Histograma da imagem original
        st.subheader("Histograma Original")
        hist_fig = plot_histogram(original)
        st.pyplot(hist_fig)
        
    with col_proc:
        st.image(processed, caption="Imagem Processada", use_column_width=True)
        
        # Histograma da imagem processada
        st.subheader("Histograma Processado")
        hist_fig_proc = plot_histogram(processed)
        st.pyplot(hist_fig_proc)
        
        # Botão para download
        buf = BytesIO()
        Image.fromarray(processed).save(buf, format="PNG")
        buf.seek(0)
        st.download_button("Baixar imagem editada", data=buf, file_name="imagem_editada.png", mime="image/png")

    # Informações da imagem
    with st.expander("Informações da imagem"):
        st.write(f"Dimensões originais: {original.shape[1]}x{original.shape[0]} pixels")
        st.write(f"Dimensões processadas: {processed.shape[1]}x{processed.shape[0]} pixels")
        st.write(f"Canais: RGB (3 canais)")
        
        # Calcular tamanho do arquivo
        buf_size = BytesIO()
        Image.fromarray(processed).save(buf_size, format="PNG")
        st.write(f"Tamanho aproximado: {len(buf_size.getvalue()) / 1024:.1f} KB")

else:
    st.info("👆 Faça upload de uma imagem ou capture da webcam para começar a edição.")
    
    # Exemplos de uso
    with st.expander("Como usar este editor"):
        st.write("""
        1. Faça upload de uma imagem ou capture da webcam
        2. Use as abas para acessar diferentes categorias de edição:
           - **Básico**: Rotação, escala e corte
           - **Cor**: Filtros predefinidos e ajustes de cor
           - **Efeitos**: Desfoque, nitidez e detecção de bordas
           - **Artístico**: Efeitos cartoon e vinheta
        3. Visualize as mudanças em tempo real
        4. Compare os histogramas para análise técnica
        5. Baixe a imagem editada quando estiver satisfeito
        """)
        
    # Sobre o aplicativo
    with st.expander("Sobre"):
        st.write("""
        Este é um editor de imagens avançado desenvolvido com Streamlit e OpenCV.
        Ele oferece recursos profissionais de edição de fotos com uma interface simples e intuitiva.
        
        **Recursos:**
        - Transformações básicas (rotação, escala, corte)
        - Filtros de cor e ajustes HSV/RGB
        - Efeitos especiais (desfoque, nitidez, detecção de bordas)
        - Efeitos artísticos (cartoon, vinheta)
        - Análise de histograma
        - Download da imagem editada
        """)